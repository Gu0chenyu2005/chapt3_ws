#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class TopicPublisher01 : public rclcpp::Node
{
public:
    // 构造函数,有一个参数为节点名称
    TopicPublisher01(std::string name) : Node(name)
    {
        //输出节点名称
        RCLCPP_INFO(this->get_logger(), "%s节点01.", name.c_str());
        //创建发布者
        command_publisher_ = this->create_publisher<std_msgs::msg::String>("topic", 10);
        //定时500ms调用一次回调函数
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(500),
            std::bind(&TopicPublisher01::timer_callback, this));
        }
private:
    void timer_callback()
    {
        //创建消息对象
        auto message = std_msgs::msg::String();
        message.data = "臭企鹅";
        //发布消息
        command_publisher_->publish(message);
        RCLCPP_INFO(this->get_logger(), "发布消息: '%s'", message.data.c_str());
    }
    // 声明话题发布者指针
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr command_publisher_;
    //声明定时器指针
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TopicPublisher01>("topic_publisher_01"));
    rclcpp::shutdown();
    return 0;
}
